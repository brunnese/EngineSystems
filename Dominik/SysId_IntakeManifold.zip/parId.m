% Parameter Identification for Intake Manifold Volume
clc, clear all, close all
run Par;

load 'dynamic_0002'
% load 'quasistatic_0001'

Vminit = par.Vm;
par0 = Vminit;
par.ModNam = 'ISC_ParId_IntakeManifold'
IdData = meas;

opt_options  = optimset( 'TolFun',1e-6,...
                     'TolX',1e-6,...
                     'MaxIter',40,...
                     'Display','iter');
                 
errorfnc_fminsearch = @(par0) Modelerror(par0, IdData, par, 'Parameter Identification');
optpar = fminsearch(errorfnc_fminsearch, par0, opt_options); 
% Problem: Vm wird negativ!!! Dann kackts ab
% und simulation scheint nie zu �ndren obwohl Vm �ndert...
Vm_opt       = optpar; 