% Parameter Identification for Intake Manifold Volume
clc, clear all, close all
run Par;

load 'dynamic_0002'
% load 'quasistatic_0001'
%%
eta0    = par.eta0;
eta1    = par.eta1;
beta0   = par.beta0;
thetaE  = par.thetaE;

par0 = [eta0, eta1, beta0, thetaE];
par.ModNam = 'ISC_ParId_TorqueAndInertia'
IdData = meas;

opt_options  = optimset( 'TolFun',1e-6,...
                     'TolX',1e-6,...
                     'MaxIter',100,...
                     'Display','iter');
                 
errorfnc_fminsearch = @(par0) Modelerror(par0, IdData, par, 'Parameter Identification');
tic
optpar = fminsearch(errorfnc_fminsearch, par0, opt_options); 
toc
parsOpt       = optpar; 

%%
figure
load dynamic_0001.mat
ValData = meas;
Modelerror(parsOpt, ValData, par, 'Evaluation on Validation Data');



