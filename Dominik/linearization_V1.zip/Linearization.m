%% File to Linearize ISCS
clc, clear all, close all
%%
run Par.m

timespan = [0 10]';

% Define constant parameters
du = -25;
ualpha = 2;
theta_m = 295;
theta_a = 295;
p_a = 10^5;
p_e = 1*10^5;
ul=0;

% Run simulation
[t, x, y] = sim('ISC_V3_ss', timespan, par.simopt);
clear timespan

% Normalization of states
norm_p_m            = y(end,1);
norm_omega_e        = y(end,5);

% Normalization of inputs
norm_du_ign         = du;
norm_u_alpha        = ualpha;

% Compute State-space representation of delays
norm_mdot_beta      = y(end,3);
delay1IC = norm_du_ign;
delay2IC = norm_mdot_beta/norm_omega_e;
delay1  = 4*pi/(2*5*norm_omega_e);
delay2  = 2*pi/norm_omega_e;
N       = 4;
[pade1num pade1den]   = pade(delay1,N);
[pade2num pade2den]   = pade(delay2,N);
[A1 B1 C1 D1]         = tf2ss(pade1num,pade1den);
[A2 B2 C2 D2]         = tf2ss(pade2num,pade2den);
%% Plot Steady-State Simulation
subplot(2,2,1)
plot(t,y(:,1)); hold on; grid on;
title('$Intake Manifold Pressure$','Interpreter','latex')
ylabel('$p_m [Pa]$','Interpreter','latex')
subplot(2,2,2)
plot(t,y(:,2)); hold on; grid on;
plot(t,y(:,3)); hold on; grid on;
title('$Massflows$','Interpreter','latex')
ylabel('$Massflow [kg/s]$','Interpreter','latex')
legend('mdot_a_l_p_h_a','mdot_b_e_t_a')
subplot(2,2,3)
plot(t,y(:,4)); hold on; grid on;
title('$Torque$','Interpreter','latex')
xlabel('$Time [sec]$','Interpreter','latex')
ylabel('Torque [Nm]','Interpreter','latex')
subplot(2,2,4)
plot(t,y(:,5)); hold on; grid on;
title('$Rotational speed$','Interpreter','latex')
xlabel('$Time [sec]$','Interpreter','latex')
ylabel('$\omega_e [rad/s]$','Interpreter','latex')
%% Linearize System
% x = Simulink.BlockDiagram.getInitialState('Linearization_TEST')
linsys = linmod('Linearization_TEST', [1 1],[1 1]); 
%% Extract System Matrices
A = linsys.a;
B = linsys.b;
C = linsys.c;
D = linsys.d;
%% Simulate Step-response
sysSS = ss(A,B,C,D);
figure
step(sysSS); grid on
%%
load dynamic_0001
Data        = meas;
pinit       = Data.p_m.signals.values(1);
omegaeinit   = Data.omega_e.signals.values(1);
timespan    = [Data.p_m.time(1) Data.p_m.time(end)];


Tu_alpha    = norm_u_alpha;
Tu_ign      = norm_du_ign;
Ty_omega_e  = norm_omega_e;
Ty_p_m      = norm_p_m;

[t_nonlin, x_nonlin, y_nonlin] = sim('ISC_V3_nonlin', timespan, par.simopt);
[t_lin, x_lin, y_lin] = sim('ISC_linear', timespan, par.simopt);
figure
subplot(3,1,1); grid on; hold on
plot(t_lin,y_lin);
ylabel('$\omega_e [rad/s]$','Interpreter','latex')
subplot(3,1,2); grid on; hold on
plot(t_lin,x_lin(:,1)/1e5);
ylabel('$p_m [bar]$','Interpreter','latex')
subplot(3,1,3); grid on; hold on
plot(t_lin,x_lin(:,2));
ylabel('$\omega_e [rad/s]$','Interpreter','latex')
xlabel('Time [sec]','Interpreter','latex')