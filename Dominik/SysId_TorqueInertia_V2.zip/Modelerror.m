function e = Modelerror(params, Data, par, FigureTitle)

% Set current parameter estimates (used in the simulation)
eta0    = params(1);   % Setting the manifold volume for the current iteration of fminsearch
eta1    = params(2);
beta0   = params(3);
thetaE  = params(4);

k1 = 1/1e5;
k2 = 1/1e3;
k3 = 1/1e3;
%% Run the simulation with parameter estimates of the current iteration
[time, x, y] = sim(     par.ModNam,...	% Name of simulink model
                        [Data.time(1) Data.time(end)],... % Time [t_start, t_end] - only two values when using fixed step
                        par.simopt);	% Simulation options

%% Calculate the error between measurement and simulation.

% e = sum((k1*(Data.p_m.signals.values-y(:,1))).^2 + (k2*(Data.omega_e.signals.values-y(:,2))).^2 + (k3*(Data.m_dot_alpha.signals.values-y(:,3))).^2); 
% e = sum((k1*(Data.p_m.signals.values-y(:,1))).^2 + (k2*(Data.omega_e.signals.values-y(:,2))).^2); 
e = sum((k2*(Data.omega_e.signals.values-y(:,2))).^2);    
% Normalize the pressure so that the error value does not have a too large
% value. This can lead to numerical problems sometimes.
% The 'sum' command only makes sense if a fixed stepsize is used. We will
% use a fixed step size in all out exercises for this class.
%% plot result of current iteration

% create plot only if par.enablePlot is not 0
close all
if 1%par.enablePlot
    
    get(0,'CurrentFigure'); % use current figure - do not set it on top in each update process
    set(gcf,'Name',FigureTitle)
%     subplot(311); box on;
%         plot(Data.mdot_in.time, Data.mdot_in.signals.values, 'Color', col(1,:));
%         grid on; hold off;
%         xlabel('Time [s]');
%         ylabel('Mass flow in [kg/s]');
%         legend('Measurements (and sim. input)','Location','NorthEast');
% 
%         set(gca,'XLim',[Data.mdot_in.time(1) Data.mdot_in.time(end)]);
%         set(gca,'YLim',[min(Data.mdot_in.signals.values)-1/10*mean(Data.mdot_in.signals.values), ...
%                         max(Data.mdot_in.signals.values)+1/10*mean(Data.mdot_in.signals.values)]);
%         title(FigureTitle)
% 
%     subplot(312); box on;
%         plot(time,x(:,2),'Color', col(2,:),'LineWidth',1.5);
%         grid on; hold off;
%         xlabel('Time [s]');
%         ylabel('Intake Manifold Temperature [K]');
%         legend('Simulation','Location','NorthEast');
% 
%         set(gca,'XLim',[Data.mdot_in.time(1) Data.mdot_in.time(end)]);
%         set(gca,'YLim',[min(x(:,2))-1/10*mean(x(:,2)) max(x(:,2))+1/10*mean(x(:,2))]);
%         
    subplot(3,1,1); box on;
        box on;
        plot(Data.p_m.time, Data.p_m.signals.values); hold on;
        grid on;
        plot(time,y(:,1),'LineWidth',1.5); hold off; % "hold off" is important here, otherwise you always see the results of all past simulations.
        xlabel('Time [s]');
        ylabel('Intake Manifold Pressure [Pa]');
        legend('Measurements','Simulation','Location','NorthEast');
        
        
        subplot(3,1,2); box on;
        box on;
        plot(Data.omega_e.time, Data.omega_e.signals.values); hold on;
        grid on;
        plot(time,y(:,2),'LineWidth',1.5); hold off; % "hold off" is important here, otherwise you always see the results of all past simulations.
        xlabel('Time [s]');
        ylabel('Omega_e [rad/s]');
        legend('Measurements','Simulation','Location','NorthEast');
        
        subplot(3,1,3); box on;
        box on;
        plot(Data.m_dot_alpha.time, Data.m_dot_alpha.signals.values); hold on;
        grid on;
        plot(time,y(:,3),'LineWidth',1.5); hold off; % "hold off" is important here, otherwise you always see the results of all past simulations.
        xlabel('Time [s]');
        ylabel('Mass flow [kg/s]');
        legend('Measurements','Simulation','Location','NorthEast');
%         
%         set(gca,'XLim',[Data.mdot_in.time(1) Data.mdot_in.time(end)]);
%         set(gca,'YLim',[min(Data.p.signals.values)-1/10*mean(Data.p.signals.values) ...
%                         max(Data.p.signals.values)+1/10*mean(Data.p.signals.values)]);
                    
    drawnow 
    % "drawnow" makes sure that the figure and plot commands are executed here and now
    


end
