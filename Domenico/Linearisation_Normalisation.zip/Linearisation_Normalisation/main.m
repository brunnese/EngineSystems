clc 
clear all

run Par;
timespan = [0 10];
du = -25;
ualpha = 2.5;
theta_m = 300;
theta_a = 295;
p_a = 10^5;
p_e = 10^5;
ul=0;

[t,x,y] = sim('ISC_MS2', timespan, par.simopt);


% %Inputs
% figure('Name','Inputs');
% subplot(2,1,1)
% grid on, hold on
% plot(t,y(:,11))
% xlabel('Time [s]')
% ylabel('$u_{\alpha}$ [%] ','interpreter','latex')
% subplot(2,1,2)
% grid on, hold on
% plot(t,y(:,12))
% xlabel('Time [s]')
% ylabel('$delta u$ [�CA (before MBT)]','interpreter','latex')

%States
figure('Name','States');
subplot(5,2,1)
grid on, hold on
plot(t,y(:,2))
xlabel('Time [s]')
ylabel('$\omega_{e}$ [rad/s]','interpreter','latex')
subplot(5,2,2)
grid on, hold on
plot(t,y(:,4))
xlabel('Time [s]')
ylabel('$T_{e}$ [Nm]','interpreter','latex')
subplot(5,2,3)
grid on, hold on
plot(t,y(:,1)/1e-5)
xlabel('Time [s]')
ylabel('$p_{m}$ [bar]','interpreter','latex')
subplot(5,2,4)
grid on, hold on
plot(t,y(:,5)*1e-5)
xlabel('Time [s]')
ylabel('$p_{e}$ [bar]','interpreter','latex')
subplot(5,2,5)
grid on, hold on
plot(t,y(:,6)*1e3)
xlabel('Time [s]')
ylabel('$\dot{m}_{\beta}$ [g/s]','interpreter','latex')
subplot(5,2,6)
grid on, hold on
plot(t,y(:,7)-273.15)
xlabel('Time [s]')
ylabel('$\vartheta_{m}$ [�C]','interpreter','latex')
subplot(5,2,7)
grid on, hold on
plot(t,y(:,3)*1e3)
xlabel('Time [s]')
ylabel('$\dot{m}_{\alpha}$ [g/s]','interpreter','latex')
subplot(5,2,8)
grid on, hold on
plot(t,y(:,8)*1e-5)
xlabel('Time [s]')
ylabel('$p_{a}$ [bar]','interpreter','latex')
subplot(5,2,9)
grid on, hold on
plot(t,y(:,9)-273.15)
xlabel('Time [s]')
ylabel('$\vartheta_{a}$ [�C]','interpreter','latex')
subplot(5,2,10)
grid on, hold on
plot(t,y(:,10)*1e6)
xlabel('Time [s]')
ylabel('$A_{alpha}$ [mm^{2}]','interpreter','latex')

%Delays
figure('Name','Delays');
subplot(2,1,1)
grid on, hold on
plot(t,y(:,13))
xlabel('Time [s]')
ylabel('$\tau_{IPS}$ [s]','interpreter','latex')
subplot(2,1,2)
grid on, hold on
plot(t,y(:,14))
xlabel('Time [s]')
ylabel('$\tau_{seg}$ [s]','interpreter','latex')
