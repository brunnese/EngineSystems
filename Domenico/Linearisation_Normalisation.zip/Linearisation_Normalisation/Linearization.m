%% File description
% Linearize the system around an operating point and normalize it.
% Do not simply press F5 and look at the result. You might learn a lot from
% this file, so take 10 minutes and go through the m-file line by line and
% comment by comment. This will make it easier for you and also for us.

%% Linearizing the system

% Load the parameters
run Par; 
    
timespan = [0 10]';
du = -25;
ualpha = 2.5;
theta_m = 300;
theta_a = 295;
p_a = 10^5;
p_e = 10^5;
ul=0;
[t, x, y] = sim('ISC_MS2', timespan, par.simopt);
clear timespan
    
% Plot states to make sure they have reached steady-state.

% %Inputs
% figure('Name','Inputs');
% subplot(2,1,1)
% grid on, hold on
% plot(t,y(:,11))
% xlabel('Time [s]')
% ylabel('$u_{\alpha}$ [%] ','interpreter','latex')
% subplot(2,1,2)
% grid on, hold on
% plot(t,y(:,12))
% xlabel('Time [s]')
% ylabel('$delta u$ [�CA (before MBT)]','interpreter','latex')

%States
figure('Name','States');
subplot(5,2,1)
grid on, hold on
plot(t,y(:,2))
xlabel('Time [s]')
ylabel('$\omega_{e}$ [rad/s]','interpreter','latex')
subplot(5,2,2)
grid on, hold on
plot(t,y(:,4))
xlabel('Time [s]')
ylabel('$T_{e}$ [Nm]','interpreter','latex')
subplot(5,2,3)
grid on, hold on
plot(t,y(:,1)/1e-5)
xlabel('Time [s]')
ylabel('$p_{m}$ [bar]','interpreter','latex')
subplot(5,2,4)
grid on, hold on
plot(t,y(:,5)*1e-5)
xlabel('Time [s]')
ylabel('$p_{e}$ [bar]','interpreter','latex')
subplot(5,2,5)
grid on, hold on
plot(t,y(:,6)*1e3)
xlabel('Time [s]')
ylabel('$\dot{m}_{\beta}$ [g/s]','interpreter','latex')
subplot(5,2,6)
grid on, hold on
plot(t,y(:,7)-273.15)
xlabel('Time [s]')
ylabel('$thetam [degC]$','interpreter','latex')
subplot(5,2,7)
grid on, hold on
plot(t,y(:,3)*1e3)
xlabel('Time [s]')
ylabel('$\dot{m}_{\alpha}$ [g/s]','interpreter','latex')
subplot(5,2,8)
grid on, hold on
plot(t,y(:,8)*1e-5)
xlabel('Time [s]')
ylabel('$p_{a}$ [bar]','interpreter','latex')
subplot(5,2,9)
grid on, hold on
plot(t,y(:,9)-273.15)
xlabel('Time [s]')
ylabel('$thetaa [degC]$','interpreter','latex')
subplot(5,2,10)
grid on, hold on
plot(t,y(:,10)*1e6)
xlabel('Time [s]')
ylabel('$Aalpha [mm^{2}]$','interpreter','latex')

%Delays
figure('Name','Delays');
subplot(2,1,1)
grid on, hold on
plot(t,y(:,13))
xlabel('Time [s]')
ylabel('$\tau_{IPS}$ [s]','interpreter','latex')
subplot(2,1,2)
grid on, hold on
plot(t,y(:,14))
xlabel('Time [s]')
ylabel('$\tau_{seg}$ [s]','interpreter','latex')

% equilibrium values
%States
omega_e_nom = y(end,1);
T_e_nom =y(end,4);
p_m_nom       = y(end,2);
p_e_nom = y(end,5);
m_dot_beta_nom=y(end,6);
theta_m_nom=y(end,7);
m_dot_alpha_nom=y(end,3);
p_a_nom=y(end,8);
theta_a_nom=y(end,9);
A_alpha_nom=y(end,10);

%Inputs
u_alpha_nom=y(end,11);
du_nom=y(end,12);

%Delays
tau_ips_nom=y(end,13);
tau_seg_nom=y(end,14);

[tau_ips_num,tau_ips_den]=pade(tau_ips_nom,4);
[tau_seg_num,tau_seg_den]=pade(tau_seg_nom,4);

[tau_ips_A,tau_ips_B,tau_ips_C,tau_ips_D]=tf2ss(tau_ips_num,tau_ips_den);
[tau_seg_A,tau_seg_B,tau_seg_C,tau_seg_D]=tf2ss(tau_seg_num,tau_seg_den);

% Linearize the system using the command linmod:
linsys = linmod('ISC_MS2_nom', [1 1 1 1 1 1 1 1 1 1], [1 1]); 
% linsys = linmod('manifold_NiceLayout', x_eq, mdotin_nom); 
% Inputs are the model name, the nominal states that were reached and 
% the nominal input, with which those states can be reached

% Display the order of the states in your linear model. Sometimes it is not
% clear, which state has which state number. 
% The following code gives the name of the integrator, that simulink uses
% as the "first" state and so on
% disp('SYSTEM STATES');
% disp(['1st state: ', num2str(linsys.StateName{1,1}(1+max(findstr(linsys.StateName{1,1},'/')):end))]);
% disp(['2nd state: ', num2str(linsys.StateName{2,1}(1+max(findstr(linsys.StateName{2,1},'/')):end))]);

% Assign the system matrices:
A = linsys.a;
B = linsys.b;
C = linsys.c;
D = linsys.d;

sysSS = ss(A,B,C,D);
figure
step(sysSS)

%% Normalizing the linear system:
% Normalization is already done using the description in the exercise 
% tutorial!
Tu  = u_alpha_nom;
Tv  = du_nom;
Ty = omega_e_nom;

%% Compare the linear with the nonlinear model

% load measurement data
load dynamic_0001; Data = meas;
% load DataValidation.mat; Data = ValData;

% Initial conditions for the nonlinear model
% Nonlinear model
p_m_init           = Data.p_m.signals.values(1);   % [Pa]
omega_e_init       = Data.omega_e.signals.values(1);                 % [rad/s]

% Linearized/normalized model - use normalized initial conditions
p_m_init_lin      	= Data.p_m.signals.values(1) / p_m_nom - 1; % [-]
omega_e_init_lin   = omega_e_init / omega_e_nom - 1;    % [-]

timespan        = [Data.time(1) Data.time(end)];
    
% Run Simulation
% Simulate the nonlinear model
[t_nonlin, x_nonlin, y_nonlin] = sim(par.ISC_MS2, timespan, par.sim_opt);
% Simulate the linearized model. There is a new model file for the
% linearized and normalized model. We simulate each model file individually
% and compare the results in a single plot. 
[t_lin, x_lin, y_lin] = sim('manifold_linear', timespan, par.sim_opt);

% You can also put the linear and nonlinear versions into one model file,
% however the parameter identification and the normalization etc. will not
% work anymore if you work like that.

% Plot both system responses.
figure('Name','Comparison Linear and Non-linear Models');
col = lines(2);
    grid on; hold on;
    plot(t_lin([1 end]), p_nom*[1 1], 'k--')
    plot(t_nonlin, y_nonlin, 'Color', col(1,:), 'LineWidth', 2 );
    plot(t_lin, y_lin, '--', 'Color', col(2,:), 'LineWidth', 2);
    xlabel('Time [s]');
    ylabel('Intake Manifold Pressure [Pa]');
    title('Step Response');
    legend('Linearization Point', 'Nonlinear model', 'Linear model','Location','best');